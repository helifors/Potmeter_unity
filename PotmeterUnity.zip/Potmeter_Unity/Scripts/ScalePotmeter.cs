using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScalePotmeter : MonoBehaviour
{

    [SerializeField] private Potmeter _potmeter;

    [SerializeField] private float _minScale;
    [SerializeField] private float _maxScale;
    // Start is called before the first frame update
 

    // Update is called once per frame
    void Update()
    {
        float normelizedScale = Mathf.Lerp(_minScale,_maxScale,_potmeter.potValue);
        transform.localScale = Vector3.one * normelizedScale;
    }
}
