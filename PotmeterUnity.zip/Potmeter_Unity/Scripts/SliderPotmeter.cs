using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderPotmeter : MonoBehaviour
{
    private Slider _slider;
    [SerializeField] private Potmeter _potmeter;

    private void Awake()
    {
        _slider = GetComponent<Slider>();
    }


    private void Update()
    {
        _slider.value = _potmeter.potValue;
    }

}
