using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potmeter : MonoBehaviour
{
    private SerialController _serialController;
    public float potValue { get; private set;}
    // Start is called before the first frame update
    private void Awake()
    {
        _serialController = GetComponent<SerialController>();
    }
 

    // Update is called once per frame
    void Update()
    {
        string message = _serialController.ReadSerialMessage();

        if (message == null)
            return;

        if (float.TryParse(message,out float value))
        {
            potValue = Mathf.InverseLerp(0,1023, value);
        }
    }
}
